﻿Public Class Main
  Inherits System.Web.UI.Page

  Private Sub Main_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
    'MakeChart("chtPie", "{label: 'Africa',backgroundColor: ['#3cba9f','#3e95cd', '#8e5ea2','#3cba9f','#e8c3b9','#c45850','#e8c3b9'],data: [40, 10, 5, 2, 20, 30, 2]}", "['January', ' February February February February', 'March1', 'April', 'May2 May2 May2 May2 May2', 'June', 'July']", ChartTypes.Pie)
    'MakeChart("chtBar", "{label: 'Africa',backgroundColor: '#3cba9f',data: [40, 10, 5, 2, 20, 30, 2]}, {label: 'aSIA',backgroundColor: '#e8c3b9',data: [50, 10, 50, 2, 20, 30, 2]}", "['January', 'February', 'March1', 'April', 'May2', 'June', 'July']", ChartTypes.Bar)


    Dim sAllChartIDs As String() = New String(1) {}
    sAllChartIDs(0) = "chtPie"
    sAllChartIDs(1) = "chtBar"

    Dim sAllChartDatas As String() = New String(1) {}
    sAllChartDatas(0) = "{label: 'Africa',backgroundColor: ['#3cba9f','#3e95cd', '#8e5ea2','#3cba9f','#e8c3b9','#c45850','#e8c3b9'],data: [40, 10, 5, 2, 20, 30, 2]}"
    sAllChartDatas(1) = "{label: 'Africa',backgroundColor: '#3cba9f',data: [40, 10, 5, 2, 20, 30, 2]}, {label: 'aSIA',backgroundColor: '#e8c3b9',data: [50, 10, 50, 2, 20, 30, 2]}"


    Dim sAllChartLabels As String() = New String(1) {}
    sAllChartLabels(0) = "['January', ' February February February February', 'March1', 'April', 'May2 May2 May2 May2 May2', 'June', 'July']"
    sAllChartLabels(1) = "['January', 'February', 'March1', 'April', 'May2', 'June', 'July']"

    Dim sAllChartTypes As String() = New String(1) {}
    sAllChartTypes(0) = ChartTypes.Pie
    sAllChartTypes(1) = ChartTypes.Bar


    ChartCreate(sAllChartIDs, sAllChartDatas, sAllChartLabels, sAllChartTypes)

    'ChartLoad(sAllChartIDs)

  End Sub
  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

  End Sub
  Enum ChartTypes
    Pie = 1
    Line = 2
    horizontalBar = 3
    Bar = 4
  End Enum

  Private Function ChartColors(pColor As String) As String
    Select Case pColor.ToUpper
      Case "BLUE" : ChartColors = "#3e95cd"
      Case "PURPLE" : ChartColors = "#8e5ea2"
      Case "GREEN" : ChartColors = "#3cba9f"
      Case "SKIN" : ChartColors = "#e8c3b9"
      Case "BROWN" : ChartColors = "#c45850"
    End Select
  End Function


  Public Sub ChartCreate(pAllChartIDs As String(), pAllChartDatas As String(), pAllChartLabels As String(), pAllChartTypes As String())

    Dim sChartType As String = "pie" 'default

    Dim p As Page = TryCast(HttpContext.Current.Handler, Page)
    Dim sb As New System.Text.StringBuilder()
    sb.Append("<script type='text/javascript'>")


    

    For i = 0 To pAllChartIDs.GetUpperBound(0)

      Select Case pAllChartTypes(i)
        Case 1
          sChartType = "pie"
        Case 2
          sChartType = "line"
        Case 3
          sChartType = "horizontalBar"
        Case 4 ' Bar is multiple date
          sChartType = "bar"
      End Select
      ' CREATE CHART(S)
      sb.Append("var config_" & pAllChartIDs(i) & " = {type: '" & sChartType & "',  data: {" & _
              "datasets: [" & pAllChartDatas(i) & "],labels:" & pAllChartLabels(i) & _
              "},  options: {" & _
              "responsive: true}};")

    Next
    ' LOAD CHART(S)
    sb.Append("window.onload = function () {")
    For i = 0 To pAllChartIDs.GetUpperBound(0)
      sb.Append("var ctx_" & pAllChartIDs(i) & " = document.getElementById('" & pAllChartIDs(i) & "').getContext('2d');window.myPie = new Chart(ctx_" & pAllChartIDs(i) & ", config_" & pAllChartIDs(i) & ");")
    Next
    sb.Append("};")

    ' WRITE A FUNCTION TO GET THE VIEW POSITION OF CHART ON SCROLL
    sb.Append(" function isScrolledIntoView(elem) {" & _
                    "  var docViewTop = $(window).scrollTop();" & _
                    "  var docViewBottom = docViewTop + $(window).height();" & _
                    "  var elemTop = $(elem).offset().top;" & _
                    "  var elemBottom = elemTop + $(elem).height();" & _
                    "  return ((elemTop <= docViewBottom) && (elemBottom >= docViewTop));}" & _
                    "$(window).scroll(function () {")
    For i = 0 To pAllChartIDs.GetUpperBound(0)
      ' ON WINDOWS SCROLL, LOAD CHART(S) ON SCROLL, SO THAT IT ANIMATE, USED FOR CHARTS WHICH ARE BELOW THE PAGE
      sb.Append("var inView_" & pAllChartIDs(i) & " = false; " & _
          " if (isScrolledIntoView('#" & pAllChartIDs(i) & "')) { " & _
            " if (inView_" & pAllChartIDs(i) & ") { return; } inView_" & pAllChartIDs(i) & " = true; " & _
            " var ctx_" & pAllChartIDs(i) & " = document.getElementById('" & pAllChartIDs(i) & "').getContext('2d'); " & _
            " window.myPie = new Chart(ctx_" & pAllChartIDs(i) & ", config_" & pAllChartIDs(i) & "); " & _
          " } else { inView_" & pAllChartIDs(i) & " = false; }")
    Next




    sb.Append("});</script>")

    ScriptManager.RegisterClientScriptBlock(p, p.[GetType](), "Script_" & sChartType, sb.ToString(), False)



  End Sub



  Private Sub ChartLoad(pAllChartIDs As String()) ' pAllChartIDs = 'chtPie','chtBar'


    'Dim sChartID As String

    Dim p As Page = TryCast(HttpContext.Current.Handler, Page)


    Dim sb As New System.Text.StringBuilder()
    sb.Append("<script type='text/javascript'>")
    sb.Append("window.onload = function () {")
    For i = 0 To pAllChartIDs.GetUpperBound(0)

       sb.Append("var ctx_" & pAllChartIDs(i) & " = document.getElementById('" & pAllChartIDs(i) & "').getContext('2d');window.myPie = new Chart(ctx_" & pAllChartIDs(i) & ", config_" & pAllChartIDs(i) & ");")




    Next
    sb.Append("};")

    'Scrolling animation starts
    sb.Append(" function isScrolledIntoView(elem) {" & _
                    "  var docViewTop = $(window).scrollTop();" & _
                    "  var docViewBottom = docViewTop + $(window).height();" & _
                    "  var elemTop = $(elem).offset().top;" & _
                    "  var elemBottom = elemTop + $(elem).height();" & _
                    "  return ((elemTop <= docViewBottom) && (elemBottom >= docViewTop));}" & _
                    "$(window).scroll(function () {")
    For i = 0 To pAllChartIDs.GetUpperBound(0)
      '
      sb.Append("var inView_" & pAllChartIDs(i) & " = false; " & _
          " if (isScrolledIntoView('#" & pAllChartIDs(i) & "')) { " & _
            " if (inView_" & pAllChartIDs(i) & ") { return; } inView_" & pAllChartIDs(i) & " = true; " & _
            " var ctx_" & pAllChartIDs(i) & " = document.getElementById('" & pAllChartIDs(i) & "').getContext('2d'); " & _
            " window.myPie = new Chart(ctx_" & pAllChartIDs(i) & ", config_" & pAllChartIDs(i) & "); " & _
          " } else { inView_" & pAllChartIDs(i) & " = false; }")
    Next




    sb.Append("});</script>")
    ScriptManager.RegisterClientScriptBlock(p, p.[GetType](), "Script_" & Now.TimeOfDay.ToString, sb.ToString(), False)



  End Sub


End Class