﻿
Partial Class App_Pages_ChartJS_ASP_DT
  Inherits System.Web.UI.Page


  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    'Page.ClientScript.RegisterClientScriptInclude("jsFileJQ", ResolveUrl("~/App_Styles/jquery-3.4.1.min.js"))
    'Page.ClientScript.RegisterClientScriptInclude("jsFileBS", ResolveUrl("~/App_Styles/bootstrap-min.js"))
    'Page.ClientScript.RegisterClientScriptInclude("jsFileCh", ResolveUrl("~/App_Styles/charts/Chart.min.js"))

    'Page.ClientScript.RegisterClientScriptInclude("jsFile08", ResolveUrl("~/App_Styles/charts/chartsapp.js"))
    'Page.ClientScript.RegisterClientScriptInclude("jsFileDL1", ResolveUrl("~/App_Styles/charts/chartjs-plugin-datalabels.js"))
    'Page.ClientScript.RegisterClientScriptInclude("jsFilechtColor", ResolveUrl("~/App_Styles/charts/chartjs-plugin-colorschemes.js")) 'https://nagix.github.io/chartjs-plugin-colorschemes/
    'Page.ClientScript.RegisterClientScriptInclude("jsFileDF1", ResolveUrl("~/App_Styles/charts/chartjs-plugin-deferred.js"))


    FillChartsMon()
    FillChartsSC()

  End Sub

  Private Sub FillChartsMon()

   

    Dim dtList As New System.Data.DataTable


    dtList.Columns.Add("Area", GetType(String))
    dtList.Columns.Add("Asia", GetType(Integer))
    dtList.Columns.Add("Africa", GetType(Integer))

    dtList.Rows.Add("Jan", 13, 24)
    dtList.Rows.Add("Feb", 63, 104)
    dtList.Rows.Add("Mar", 54, 70)
    dtList.Rows.Add("Apr", 9, 90)
    dtList.Rows.Add("May", 53, 99)
    dtList.Rows.Add("Jun", 100, 30)


    ChartArrayForLabelsAndDatas_Line(dtList, "Area", "STR", "chtlabelsAREA")
    ChartArrayForLabelsAndDatas_Line(dtList, "Asia", "INT", "chtdataAREA_ASIA")
    ChartArrayForLabelsAndDatas_Line(dtList, "Africa", "INT", "chtdataAREA_AFRICA")



  End Sub

  Private Sub FillChartsSC()

    Dim dtList As New System.Data.DataTable


    dtList.Columns.Add("Player", GetType(String))
    dtList.Columns.Add("Goals", GetType(Integer))

    dtList.Rows.Add("Pele", 24)
    dtList.Rows.Add("Messi", 63)
    dtList.Rows.Add("Maradona", 54)
    dtList.Rows.Add("Ronaldo", 90)

    ChartArrayForLabelsAndDatas_Pie(dtList, "Player", "STR", "chtlabels_Pie_MEIN")
    ChartArrayForLabelsAndDatas_Pie(dtList, "Goals", "INT", "chtdataIN_Pie_MEIN")


  End Sub
  Private Sub ChartArrayForLabelsAndDatas_Line(dt As System.Data.DataTable, sColName As String, sDataType As String, jsArrayName As String)
    Dim aDBValue As String() = New String(dt.Rows.Count - 1) {}

    For i = 0 To dt.Rows.Count - 1
      aDBValue(i) = dt.Rows(i)(sColName).ToString
    Next

    Dim createArrayScript As String

    If sDataType.ToUpper = "INT" Then
      createArrayScript = String.Format("var " & jsArrayName & " = [{0}];", String.Join(",", aDBValue))
    Else 'STRING, APPEND SINGLE QUOTE TO MAKE LIKE 'jan','feb'...
      createArrayScript = String.Format("var " & jsArrayName & " = [{0}];", String.Join("','", aDBValue))
      createArrayScript = createArrayScript.Replace("[", "['")
      createArrayScript = createArrayScript.Replace("]", "']")
    End If

    'Dim p As Page = TryCast(HttpContext.Current.Handler, Page)

    Page.ClientScript.RegisterStartupScript(Me.GetType, "schtArray_" & jsArrayName, createArrayScript, True)

  End Sub

  Private Sub ChartArrayForLabelsAndDatas_Pie(dt As System.Data.DataTable, sColName As String, sDataType As String, jsArrayName As String)
    Dim aDBValue As String() = New String(dt.Rows.Count - 1) {}

    For i = 0 To dt.Rows.Count - 1
      aDBValue(i) = dt.Rows(i)(sColName).ToString
    Next

    Dim createArrayScript As String

    If sDataType.ToUpper = "INT" Then
      createArrayScript = String.Format("var " & jsArrayName & " = [{0}];", String.Join(",", aDBValue))
    Else 'STRING, APPEND SINGLE QUOTE TO MAKE LIKE 'jan','feb'...
      createArrayScript = String.Format("var " & jsArrayName & " = [{0}];", String.Join("','", aDBValue))
      createArrayScript = createArrayScript.Replace("[", "['")
      createArrayScript = createArrayScript.Replace("]", "']")
    End If

    'Dim p As Page = TryCast(HttpContext.Current.Handler, Page)

    Page.ClientScript.RegisterStartupScript(Me.GetType, "schtArray_" & jsArrayName, createArrayScript, True)

  End Sub


 

End Class
