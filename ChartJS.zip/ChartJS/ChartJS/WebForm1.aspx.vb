﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    Page.ClientScript.RegisterClientScriptInclude("jsFileJQ", ResolveUrl("~/App_Styles/jquery-3.4.1.min.js"))
    Page.ClientScript.RegisterClientScriptInclude("jsFileBS", ResolveUrl("~/App_Styles/bootstrap-min.js"))
    Page.ClientScript.RegisterClientScriptInclude("jsFileCh", ResolveUrl("~/App_Styles/charts/Chart.min.js"))

    End Sub

End Class